﻿using System.Collections.Generic;

namespace AzureCalculatorTest
{
    public class AzureSqlCostCsv
    {
        public string Region { get; set; }
        public string AzureVmProfile { get; set; }
        public string LicenseType { get; set; }
        public decimal Cost { get; set; }
        public string OperatingSystem { get; set; }
    }

    public class AzureSqlCost
    {        
        public string AzureVmProfile { get; set; }
        public Dictionary<string, decimal> WindowsCosts { get; set; }
        public Dictionary<string, decimal> LinuxCosts { get; set; }
    }

    public enum OsType {
        Windows, 
        Linux
    }
}
