﻿using System.Collections.Generic;
using System.Text;
using System.IO;

namespace AzureCalculatorTest
{
    class Program
    {
        static void Main(string[] args)
        {
            GetRecoverCosts();
        }

        public static void GetRecoverCosts()
        {
            var regions = new List<string>() { "asia-pacific-east", "asia-pacific-southeast", "australia-east", "australia-southeast",
            "brazil-south", "canada-central", "canada-east", "central-india", "south-india", "europe-north", "europe-west", "france-central",
            "france-south", "germany-central", "germany-northeast", "japan-east", "japan-west", "korea-central", "korea-south",
            "united-kingdom-south", "united-kingdom-west", "us-central", "us-east", "us-east-2", "us-north-central", "us-south-central",
            "us-west-central", "us-west", "us-west-2", "usgov-arizona", "usgov-iowa", "usgov-texas", "usgov-virginia"};
            var azureCostTest = new AzureRecoverCostTest();

            var azureCost = azureCostTest.GetRecoverCosts(regions);
            WriteAzurteRecoverCostToCsv(azureCost);
        }

        public static void GetStorageCosts()
        {
            var regions = new List<string>() { "West Europe", "East US", "East US 2", "North Europe" };
            var discProfilesHdd = new List<string>() { "s4", "s6", "s10", "s15", "s20", "s30", "s40", "s50" };
            var discProfilesSsd = new List<string>() { "e10", "e15", "e20", "e30", "e40", "e50" };
            var azureCostTest = new AzureStorageCostTest();

            var azureCost = azureCostTest.GetStorageCosts(regions, discProfilesHdd, discProfilesSsd);

            WriteAzurteStorageCostToCsv(azureCost);
        }


        public static void GetVmComputeCosts()
        {
            var regions = new List<string>() { "West Europe", "East US", "East US 2", "North Europe" };
            var profiles = new List<string>() { "d1", "d2", "d3", "d4", "d11", "d12", "d13", "d14", "d1v2", "d2v2", "d5v2" };
            var azureCostTest = new AzureComputerCostTest();

            var azureCost = azureCostTest.GetComputeCosts(regions, profiles);
            var azureCostsForCsv = azureCostTest.GetAzureComputeCostCsv(azureCost);
            WriteAzurteVmComputeCostToCsv(azureCostsForCsv);
        }

        public static void GetSqlCosts()
        {
            var profiles = new List<string>() { "d1", "d2", "d3", "d4", "d14", "d15v2", "d32v3", "d64v3", "m128ms" };
            var azureCostTest = new AzureSqlCostTest();

            var azureCost = azureCostTest.GetSqlCosts(profiles);
            var azureCostsForCsv = azureCostTest.GetAzureSqlCostCsv(azureCost);
            WriteAzurteSqlCostToCsv(azureCostsForCsv);
        }

        public static void WriteAzurteRecoverCostToCsv(List<AzureRecoverCost> azureRecoverCostCsvs)
        {
            var csv = new StringBuilder();
            //headers
            var csvHeader = "region,Cost Customer,Cost Azure";
            csv.AppendLine(csvHeader);

            foreach (var cost in azureRecoverCostCsvs)
            {
                var csvLine = $"{cost.Region}, {cost.CostCustomer}, {cost.CostAzure}";

                csv.AppendLine(csvLine);
            }
            File.WriteAllText(@"C:\Users\ryans\Documents\Work\C#\AzureCalculatorTest\AzureCalculatorTest\testRecoverCostData.csv",
                csv.ToString());

        }

        public static void WriteAzurteVmComputeCostToCsv(List<AzureComputeCostCsv> azureComputeCostCsvs)
        {
            var csv = new StringBuilder();
            //headers
            var csvHeader = "region,azure vm,windows PAYG,Win 1 y RI,Win 3 y RI,linux PAYG,linux 1 y RI,linux 3 y RI";
            csv.AppendLine(csvHeader);

            foreach (var cost in azureComputeCostCsvs)
            {
                var csvLine = $"{cost.Region},{cost.AzureVmProfile},{cost.WindowsCost},{cost.WindowsRi1YearCost}," +
                    $"{cost.WindowsRi3YearCost},{cost.LinuxCost},{cost.LinuxRi1YearCost},{cost.LinuxRi3YearCost}";

                csv.AppendLine(csvLine);
            }
            File.WriteAllText(@"C:\Users\ryans\Documents\Work\C#\AzureCalculatorTest\AzureCalculatorTest\testVmComputeCostData.csv",
                csv.ToString());

        }

        public static void WriteAzurteStorageCostToCsv(List<AzureStorageCost> azureStorageCostCsvs)
        {
            var csv = new StringBuilder();
            //headers
            var csvHeader = "region,disk azure,unit cost";
            csv.AppendLine(csvHeader);

            foreach (var cost in azureStorageCostCsvs)
            {
                var csvLine = $"{cost.Region},{cost.DiskProfile},{cost.Cost}";
                csv.AppendLine(csvLine);
            }
            File.WriteAllText(@"C:\Users\ryans\Documents\Work\C#\AzureCalculatorTest\AzureCalculatorTest\testStorageCosttData.csv",
                csv.ToString());

        }

        public static void WriteAzurteSqlCostToCsv(List<AzureSqlCostCsv> azureComputeCostCsvs)
        {
            var csv = new StringBuilder();
            //headers
            var csvHeader = "region,azure vm,license type,cost,operating system";
            csv.AppendLine(csvHeader);

            foreach (var cost in azureComputeCostCsvs)
            {
                var csvLine = $"{cost.Region},{cost.AzureVmProfile},{cost.LicenseType},{cost.Cost},{cost.OperatingSystem}";

                csv.AppendLine(csvLine);
            }
            File.WriteAllText(@"C:\Users\ryans\Documents\Work\C#\AzureCalculatorTest\AzureCalculatorTest\testSqlServerCostData.csv",
                csv.ToString());
        }
    }
}
