﻿namespace AzureCalculatorTest
{
    public class AzureComputeCostCsv
    {
        public string Region { get; set; }
        public string AzureVmProfile { get; set; }
        public decimal WindowsCost { get; set; }
        public decimal WindowsRi1YearCost { get; set; }
        public decimal WindowsRi3YearCost { get; set; }
        public decimal LinuxCost { get; set; }
        public decimal LinuxRi1YearCost { get; set; }
        public decimal LinuxRi3YearCost { get; set; }
    }

    public class AzureProfile
    {
        public string Region { get; set; }
        public string AzureVmProfile { get; set; }
        public AzureComputeCost WindowsCosts { get; set; }
        public AzureComputeCost LinuxCosts { get; set; }
    }

    public class AzureComputeCost
    {
        public MachineType MachineType { get; set; }
        public decimal ComputeCost { get; set; }
        public decimal Ri1YearCost { get; set; }
        public decimal Ri3YearCost { get; set; }
    }
    public enum MachineType
    {
        Windows, 
        Linux, 
        SQL
    }
}
