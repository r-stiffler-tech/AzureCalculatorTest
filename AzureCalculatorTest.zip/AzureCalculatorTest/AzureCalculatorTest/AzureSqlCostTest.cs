﻿using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace AzureCalculatorTest
{
    public class AzureSqlCostTest
    {
        private IWebDriver _driver = new FirefoxDriver();
        private readonly string _region;
        private readonly List<string> _licenceWindowsTypes;
        private readonly List<string> _licenceLinuxTypes;

        public AzureSqlCostTest()
        {

            _region = "West Europe";
            _licenceWindowsTypes = new List<string>() { "sql-enterprise", "sql-standard", "sql-web" };
            _licenceLinuxTypes = new List<string>() { "sql-linux-enterprise", "sql-linux-standard", "sql-linux-web" };

            _driver.Url = "https://azure.microsoft.com/en-gb/pricing/calculator/";
            _driver.FindElement(By.Id("create-virtual-machines")).Click();
            Thread.Sleep(30000);
            new SelectElement(_driver.FindElement(By.Name("region"))).SelectByText(_region);
        }

        public List<AzureSqlCost> GetSqlCosts(List<string> azureVmProfiles)
        {
            var results = new List<AzureSqlCost>();                     
           
            foreach (var azureVmProfile in azureVmProfiles)
            {
                new SelectElement(_driver.FindElement(By.Id("size"))).SelectByValue(azureVmProfile);

                var azureProfileComputeCost = new AzureSqlCost
                {                   
                    AzureVmProfile = azureVmProfile,
                    WindowsCosts = GetAzureSqlCostForMachineType(OsType.Windows),
                    LinuxCosts = GetAzureSqlCostForMachineType(OsType.Linux)
                };
                results.Add(azureProfileComputeCost);
            }
            
            return results;
        }

        private Dictionary<string, decimal> GetAzureSqlCostForMachineType(OsType osType)
        { 
            var operatingSystem = osType == OsType.Linux ? "Linux" : "Windows";
            var machineType = osType == OsType.Linux ? "sql-linux" : "sql";

            new SelectElement(_driver.FindElement(By.Name("operatingSystem"))).SelectByText(operatingSystem);

            var result = new Dictionary<string, decimal>();


            //reading data from screen

            // set the type to machineType
            //find Licence drop down 

            new SelectElement(_driver.FindElement(By.Name("type"))).SelectByValue(machineType);
            Thread.Sleep(1000);
            var licenses = osType == OsType.Linux ? _licenceLinuxTypes : _licenceWindowsTypes;
            foreach (var licence in licenses)
            {

                new SelectElement(_driver.FindElement(By.Name("license"))).SelectByValue(licence);
                string textd1cfirst = _driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='='])[1]/following::span[2]")).Text;
                string textd1csecond = textd1cfirst.Replace("Per month", "").Replace("£", "");
                string textd1c = textd1csecond.Trim();
                Thread.Sleep(1000);

                decimal.TryParse(textd1c, out decimal cost);
     
                result.Add(licence, cost);
            }
                
            

            return result;
        }

        public List<AzureSqlCostCsv> GetAzureSqlCostCsv(List<AzureSqlCost> azureSqlCosts)
        {
            var results = new List<AzureSqlCostCsv>();
            foreach (var azureSqlCost in azureSqlCosts)
            {
                results.AddRange(GetSqlCostCsv(OsType.Linux, azureSqlCost));
                results.AddRange(GetSqlCostCsv(OsType.Windows, azureSqlCost));
            }
            return results;
        }

        private List<AzureSqlCostCsv> GetSqlCostCsv(OsType osType, AzureSqlCost azureSqlCost)
        {
            var results = new List<AzureSqlCostCsv>();
            var licenses = osType == OsType.Linux ? _licenceLinuxTypes : _licenceWindowsTypes;
            foreach (var license in licenses)
            {
                var csvLine = new AzureSqlCostCsv()
                {
                    Region = _region,
                    AzureVmProfile = azureSqlCost.AzureVmProfile
                };
                csvLine.LicenseType = license;
                csvLine.OperatingSystem = osType.ToString();
                csvLine.Cost = osType == OsType.Linux ? azureSqlCost.LinuxCosts[license] : azureSqlCost.WindowsCosts[license];
                results.Add(csvLine);
            }
            return results;
        }

        
    }
}
