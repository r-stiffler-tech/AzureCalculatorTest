﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzureCalculatorTest
{
    public class AzureRecoverCost
    {
        public string Region { get; set; }
        public decimal CostCustomer { get; set; }
        public decimal CostAzure { get; set; }
    }

}
