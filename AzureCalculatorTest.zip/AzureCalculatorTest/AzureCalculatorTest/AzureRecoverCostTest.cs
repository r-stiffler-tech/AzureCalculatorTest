﻿using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace AzureCalculatorTest
{
    public class AzureRecoverCostTest
    {
        private IWebDriver driver = new FirefoxDriver();

        public AzureRecoverCostTest()
        {
            driver.Url = "https://azure.microsoft.com/en-gb/pricing/calculator/";
            driver.FindElement(By.ClassName("product-search")).SendKeys("Recovery");
            Thread.Sleep(5000);
            driver.FindElement(By.ClassName("product")).Click();
        }

        public List<AzureRecoverCost> GetRecoverCosts(List<string> regions)
        {
            var results = new List<AzureRecoverCost>();
            foreach (var region in regions)
            {
                var azureProfileRecoverCost = new AzureRecoverCost
                {
                    Region = region,
           
                };
                azureProfileRecoverCost.CostCustomer = GetRecoverCostForRegionCustomer(region);
                azureProfileRecoverCost.CostAzure = GetRecoverCostForRegionAzure(region);
                results.Add(azureProfileRecoverCost);
            }
            return results;
        }

        private decimal GetRecoverCostForRegionAzure(string region)
        {
            var result = new Dictionary<string, decimal>();

            new SelectElement(driver.FindElement(By.Name("region"))).SelectByValue(region);
            var customer_sites_input = driver.FindElement(By.Id("azure"));
            customer_sites_input.Clear();
            customer_sites_input.SendKeys("1");

            string price1first = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='='])[2]/following::span[2]")).Text;
            string price1second = price1first.Replace("£", "");
            string price1 = price1second.Trim();
            Thread.Sleep(1000);

            decimal.TryParse(price1, out decimal recoverPrice);

            return recoverPrice;
        }

        private decimal GetRecoverCostForRegionCustomer(string region)
        {
            var result = new Dictionary<string, decimal>();

                new SelectElement(driver.FindElement(By.Name("region"))).SelectByValue(region);
                var customer_sites_input = driver.FindElement(By.Id("customer"));
                customer_sites_input.Clear();
                customer_sites_input.SendKeys("1");

                string price1first = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='='])[1]/following::span[2]")).Text;
                string price1second = price1first.Replace("£", "");
                string price1 = price1second.Trim();
                Thread.Sleep(1000);

                decimal.TryParse(price1, out decimal recoverPrice);

            return recoverPrice;
        }    
    }
}
