﻿using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace AzureCalculatorTest
{
    public class AzureComputerCostTest
    {
        private IWebDriver driver = new FirefoxDriver();

        public AzureComputerCostTest()
        {
            driver.Url = "https://azure.microsoft.com/en-gb/pricing/calculator/";
            driver.FindElement(By.Id("create-virtual-machines")).Click();
            Thread.Sleep(30000);
        }

        public List<AzureProfile> GetComputeCosts(List<string> regions, List<string> azureVmProfiles)
        {
            var results = new List<AzureProfile>();
            foreach (var region in regions)
            {

                //select the region in the ui
                var linuxCost = GetComputeCostForMachineType(MachineType.Linux, azureVmProfiles, region);
                var windowsCost = GetComputeCostForMachineType(MachineType.Windows, azureVmProfiles, region);

                foreach (var azureVmProfile in azureVmProfiles)
                {
                    var azureProfileComputeCost = new AzureProfile
                    {
                        Region = region,
                        AzureVmProfile = azureVmProfile,
                        LinuxCosts = linuxCost[azureVmProfile],
                        WindowsCosts = windowsCost[azureVmProfile]
                    };
                    results.Add(azureProfileComputeCost);
                }
            }
            return results;
        }

        private Dictionary<string, AzureComputeCost> GetComputeCostForMachineType(MachineType machineType, List<string> azureVmProfiles, string region)
        {

            new SelectElement(driver.FindElement(By.Name("region"))).SelectByText(region);

            var machineTypeStr = machineType == MachineType.Linux ? "Linux" : "Windows";
            new SelectElement(driver.FindElement(By.Name("operatingSystem"))).SelectByText(machineTypeStr);

            var result = new Dictionary<string, AzureComputeCost>();
            foreach (var azureVmProfile in azureVmProfiles)
            {
                var azureComputeCost = new AzureComputeCost();
                azureComputeCost.MachineType = machineType;
                //reading data from screen

                driver.FindElements(By.ClassName("calculator-radio-label"))?.FirstOrDefault(x => x.Text.Contains("Pay as you go")).Click();

                new SelectElement(driver.FindElement(By.Id("size"))).SelectByValue(azureVmProfile);
                string textd1afirst = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='='])[1]/following::span[2]")).Text;
                string textd1asecond = textd1afirst.Replace("Per month", "").Replace("£","");
                string textd1a = textd1asecond.Trim();
                Thread.Sleep(1000);

                driver.FindElements(By.ClassName("calculator-radio-label"))?.FirstOrDefault(x => x.Text.Contains("1 year reserved")).Click();

                new SelectElement(driver.FindElement(By.Id("size"))).SelectByValue(azureVmProfile);
                string textd1bfirst = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='='])[1]/following::span[2]")).Text;
                string textd1bsecond = textd1bfirst.Replace("Effective cost per month", "").Replace("£","");
                string textd1b = textd1bsecond.Trim();
                Thread.Sleep(1000);

                driver.FindElements(By.ClassName("calculator-radio-label"))?.FirstOrDefault(x => x.Text.Contains("3 year reserved")).Click();

                new SelectElement(driver.FindElement(By.Id("size"))).SelectByValue(azureVmProfile);
                string textd1cfirst = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='='])[1]/following::span[2]")).Text;
                string textd1csecond = textd1cfirst.Replace("Effective cost per month", "").Replace("£","");
                string textd1c = textd1csecond.Trim();
                Thread.Sleep(1000);

                decimal.TryParse(textd1a, out decimal testa);
                azureComputeCost.ComputeCost = testa;
                decimal.TryParse(textd1b, out decimal testb);
                azureComputeCost.Ri1YearCost = testb;
                decimal.TryParse(textd1c, out decimal testc);
                azureComputeCost.Ri3YearCost = testc;
                result.Add(azureVmProfile, azureComputeCost);
            }

            return result;
        }

        public List<AzureComputeCostCsv> GetAzureComputeCostCsv(List<AzureProfile> azureProfileCosts)
        {
            var results = new List<AzureComputeCostCsv>();
            foreach (var azureProfile in azureProfileCosts)
            {
                var csvLine = new AzureComputeCostCsv()
                {
                    Region = azureProfile.Region,
                    AzureVmProfile = azureProfile.AzureVmProfile,
                    WindowsCost = azureProfile.WindowsCosts.ComputeCost,
                    WindowsRi1YearCost = azureProfile.WindowsCosts.Ri1YearCost,
                    WindowsRi3YearCost = azureProfile.WindowsCosts.Ri3YearCost,
                    LinuxCost = azureProfile.LinuxCosts.ComputeCost,
                    LinuxRi1YearCost = azureProfile.LinuxCosts.Ri1YearCost,
                    LinuxRi3YearCost = azureProfile.LinuxCosts.Ri3YearCost,
                };

                results.Add(csvLine);
            }
            return results;
        }

        
    }
}
