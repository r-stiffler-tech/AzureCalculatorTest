﻿namespace AzureCalculatorTest
{
    public class AzureStorageCost
    {
        public string Region { get; set; }
        public string DiskProfile { get; set; }
        public decimal Cost { get; set; }
    }

    public enum DiskType
    {
        HDD,
        SSD
    }
}
