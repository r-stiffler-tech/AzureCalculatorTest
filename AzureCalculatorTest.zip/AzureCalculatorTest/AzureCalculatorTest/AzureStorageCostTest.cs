﻿using System.Collections.Generic;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace AzureCalculatorTest
{
    public class AzureStorageCostTest
    {
        public List<AzureStorageCost> GetStorageCosts(List<string> regions, List<string> azureDiskProfilesHdd, List<string> azureDiskProfilesSsd)
        {
            var results = new List<AzureStorageCost>();
            foreach (var region in regions)
            {
                results.AddRange(GetAzureStorageCostForDiskType(DiskType.HDD, azureDiskProfilesHdd, region));
                results.AddRange(GetAzureStorageCostForDiskType(DiskType.SSD, azureDiskProfilesSsd, region));
            }
            return results;
        }

        private List<AzureStorageCost> GetAzureStorageCostForDiskType(DiskType diskType, List<string> azureDiskProfiles, string region)
        {
            var storageCosts = GetComputeCostForMachineType(diskType, azureDiskProfiles, region);

            var results = new List<AzureStorageCost>();
            foreach (var azureDiskProfile in azureDiskProfiles)
            {
                var azureProfileComputeCost = new AzureStorageCost
                {
                    Region = region,
                    DiskProfile = azureDiskProfile,
                    Cost = storageCosts[azureDiskProfile],

                };
                results.Add(azureProfileComputeCost);
            }
            return results;
        }


        private Dictionary<string, decimal> GetComputeCostForMachineType(DiskType diskType, List<string> azureDiskProfiles, string region)
        {
            IWebDriver driver = new FirefoxDriver();

            driver.Url = "https://azure.microsoft.com/en-gb/pricing/calculator/";
            driver.FindElement(By.Id("create-virtual-machines")).Click();
            Thread.Sleep(20000);


            new SelectElement(driver.FindElement(By.Name("region"))).SelectByText(region);

            var machineTypeStr = "Linux"; //this does nto matter for disks prices
            new SelectElement(driver.FindElement(By.Name("operatingSystem"))).SelectByText(machineTypeStr);

            var result = new Dictionary<string, decimal>();
            var diskTypeStr = diskType == DiskType.HDD ? "standardhdd" : "standardssd";

            foreach (var azureDiskProfile in azureDiskProfiles)
            {
                //grab price for the disk
                //select unit disk = 1

                new SelectElement(driver.FindElement(By.Name("managedDiskTier"))).SelectByValue(diskTypeStr);

                var inputDiskNum = driver.FindElement(By.Id("managedDisks"));
                inputDiskNum.Clear();
                inputDiskNum.SendKeys("1");

                new SelectElement(driver.FindElement(By.Id("managedDiskType"))).SelectByValue(azureDiskProfile);
                string disc1first = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='='])[2]/following::span[2]")).Text;
                string disc1second = disc1first.Replace("£","");
                string disc1 = disc1second.Trim();
                Thread.Sleep(1000);

                decimal.TryParse(disc1, out decimal diskPrice);
               
               
                result.Add(azureDiskProfile, diskPrice);
            }

            return result;
        }

        
    }
}
